//
//  LoginViewController.swift
//  MessagingApp
//
//  Created by Mayank Singh on 03/05/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class LoginViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var signInSegment: UISegmentedControl!
    @IBOutlet weak var signInLabel: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var emailTextField: UITextField!
    let imagePicker = UIImagePickerController()
    var ref: DatabaseReference!

    
    var isSignIn: Bool = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()

        
        let tapGesture = UITapGestureRecognizer()
        tapGesture.addTarget(self, action: #selector(LoginViewController.openGallery(tapGesture:)))
        myImageView.isUserInteractionEnabled = true
        myImageView.addGestureRecognizer(tapGesture)
        

        // Do any additional setup after loading the view.
    }
    
    @objc func openGallery(tapGesture: UITapGestureRecognizer) {
        photoImageSetUp()
        
    }
    
    @IBAction func signInSelectorChange(_ sender: Any) {
        
        isSignIn = !isSignIn
        
        if isSignIn {
            
            signInLabel.text = "Sign In"
            signInButton.setTitle("Sign In", for: .normal)
        } else {
            
            signInLabel.text = "Register"
            signInButton.setTitle("Register", for: .normal)
        }
 
    }
    
    @IBAction func signInButtonTapped(_ sender: Any) {
        
        self.saveFIRData()
        
        
//        if let email = emailTextField.text , let password = passwordTextField.text {
//
//            if isSignIn {
//                Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
//                    if let user = user {
//                        print("sign in user res \(String(describing: user.user.email))")
//                    } else {
//                        print("getting an error" ,(error?.localizedDescription)!)
//                    }
//                }
//            } else {
//                Auth.auth().createUser(withEmail: email, password: password) { (user, error) in
//
//                    if let user = user {
//                    print("register user res \(user)")
//                    } else {
//                        print("getting an error" ,(error?.localizedDescription)!)
//                    }
//                }
//            }
        }
    
    func saveFIRData() {
        
        self.uploadImage(self.myImageView.image!) { (url) in
            
            self.saveImage( profileURL: url!, completion: { (sussess) in
                print("yes")
            })
        }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}



extension LoginViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func photoImageSetUp()  {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.delegate = self
            imagePicker.isEditing = true
            self.present(imagePicker, animated: true, completion: nil)
            
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        myImageView.image = image
        self.dismiss(animated: true, completion: nil)
     }
    
    
}


extension LoginViewController {
    
    func uploadImage(_ image: UIImage, completion: @escaping (_ url: URL?) -> ())  {
        
        let storageRef = Storage.storage().reference()
        let riversRef = storageRef.child("images/rivers.png")
        let imageData = myImageView.image?.pngData()
        let metaData = StorageMetadata()
        metaData.contentType = "image/png"
        
        riversRef.putData(imageData!, metadata: metaData) { (metadata, error) in
            
            if error == nil {
                
                print("success")
                riversRef.downloadURL(completion: { (url, error) in
                    completion(url!)
                })
            } else {
                
                print("error in save image ")
                completion(nil)
            }

        }
        
    }
        
        func saveImage( profileURL: URL, completion:  @escaping (_ url: URL?) -> ()) {
            
            let dict = ["hi": "hello", "do":"don't", "bye": "Good Bye", "profileUrl" : profileURL.absoluteURL] as [String : Any]
            
            self.ref.child("Posts").childByAutoId().setValue(dict)
            
        }
        
    
        
        
        
    
    
}
