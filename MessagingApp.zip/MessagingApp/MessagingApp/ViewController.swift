//
//  ViewController.swift
//  MessagingApp
//
//  Created by Mayank Singh on 02/05/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import FirebaseDatabase


class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var ref: DatabaseReference!
    var databaseHandle: DatabaseHandle?

    var postData = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.dataSource = self
        ref = Database.database().reference()
        
        databaseHandle = ref.child("Posts").observe(.childAdded) { (snapshot) in
            
            let post = snapshot.value as? String
            if let actualPost = post {
            self.postData.append(actualPost)
                self.tableView.reloadData()
            }
        }

        // Do any additional setup after loading the view, typically from a nib.
    }


}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.postData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath)
        cell.textLabel?.text = postData[indexPath.row]
        return cell
    }
    
    
    
}

